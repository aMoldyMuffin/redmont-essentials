import 'dotenv/config';
import {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActivityType,
} from 'discord.js';
import { startApiServer } from './api.js';
import { claimOrder, getLeaderboard, getStaffStats, getOpenOrderCount } from './db.js';
import { buildOrderEmbed, buildClaimButton } from './orders.js';

const token = process.env.DISCORD_TOKEN;
const guildId = process.env.DISCORD_GUILD_ID;
const clientId = process.env.DISCORD_CLIENT_ID;
const staffRoleId = process.env.STAFF_ROLE_ID;
const ordersChannelId = process.env.ORDERS_CHANNEL_ID;
const websiteUrl = process.env.WEBSITE_URL || 'https://example.com';
const apiPort = Number(process.env.PORT || process.env.API_PORT || 3847);
const apiSecret = process.env.MONTY_API_SECRET;

if (!token || !guildId || !clientId) {
  console.error('Missing DISCORD_TOKEN, DISCORD_GUILD_ID, or DISCORD_CLIENT_ID');
  process.exit(1);
}

if (!ordersChannelId) {
  console.warn('Warning: ORDERS_CHANNEL_ID not set — website orders will fail until configured.');
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

function isStaff(member) {
  if (!member) return false;
  if (member.permissions.has('ManageMessages')) return true;
  if (staffRoleId && member.roles.cache.has(staffRoleId)) return true;
  return false;
}

const commands = [
  new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Redmont Essentials shop info'),
  new SlashCommandBuilder()
    .setName('kits')
    .setDescription('List starter gear kits'),
  new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Staff leaderboard by order weight points'),
  new SlashCommandBuilder()
    .setName('mystats')
    .setDescription('Your order claim stats'),
  new SlashCommandBuilder()
    .setName('orders')
    .setDescription('How many orders are waiting to be claimed'),
].map((c) => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(token);
  await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
  console.log('Monty slash commands registered.');
}

function formatLeaderboard(rows) {
  if (!rows.length) return 'No claims yet — be the first to claim an order!';

  return rows
    .map((row, i) => {
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
      return `${medal} **${row.username}** — ${row.total_weight} pts (${row.orders_claimed} orders)`;
    })
    .join('\n');
}

client.once('ready', () => {
  console.log(`Monty is online as ${client.user.tag}`);
  client.user.setActivity('Redmont Essentials orders', { type: ActivityType.Watching });

  if (apiSecret && ordersChannelId) {
    startApiServer(client, { port: apiPort, secret: apiSecret, ordersChannelId });
  } else {
    console.warn('Monty API not started — set MONTY_API_SECRET and ORDERS_CHANNEL_ID');
  }
});

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('monty_claim:')) {
      const orderId = interaction.customId.split(':')[1];

      if (!isStaff(interaction.member)) {
        await interaction.reply({
          content: 'Only staff can claim orders.',
          ephemeral: true,
        });
        return;
      }

      const claimed = claimOrder(orderId, interaction.user.id, interaction.user.username);
      if (!claimed) {
        await interaction.reply({
          content: 'This order was already claimed or does not exist.',
          ephemeral: true,
        });
        return;
      }

      await interaction.update({
        content: `✅ Order **#${orderId}** claimed by ${interaction.user}`,
        embeds: [buildOrderEmbed(claimed, { claimed: true })],
        components: [buildClaimButton(orderId, true)],
      });
      return;
    }

    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'shop') {
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xd4af37)
            .setTitle('Redmont Essentials')
            .setDescription('Everything you need to get started on Democracy Craft.')
            .addFields(
              { name: 'Website', value: websiteUrl, inline: false },
              { name: 'Order online', value: `${websiteUrl}/order.html`, inline: false },
            )
            .setFooter({ text: 'Monty · Redmont Essentials' }),
        ],
      });
      return;
    }

    if (interaction.commandName === 'kits') {
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xd4af37)
            .setTitle('Starter Gear Kits')
            .addFields(
              { name: '🎒 Survival Starter (1 pt)', value: 'Stone tools, food & basics', inline: false },
              { name: '⚔️ Adventurer Kit (3 pts)', value: 'Iron armor, tools & supplies', inline: false },
              { name: '🏗️ Builder Bundle (2 pts)', value: 'Blocks, glass & decor', inline: false },
            ),
        ],
      });
      return;
    }

    if (interaction.commandName === 'leaderboard') {
      const rows = getLeaderboard(10);
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xd4af37)
            .setTitle('🏆 Staff Leaderboard')
            .setDescription(formatLeaderboard(rows))
            .setFooter({ text: 'Ranked by weighted order points · Monty' }),
        ],
      });
      return;
    }

    if (interaction.commandName === 'mystats') {
      const stats = getStaffStats(interaction.user.id);
      if (!stats) {
        await interaction.reply({
          content: 'You have not claimed any orders yet. Claim one from the orders channel!',
          ephemeral: true,
        });
        return;
      }

      const rank = getLeaderboard(100).findIndex((r) => r.user_id === interaction.user.id) + 1;
      await interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle('📊 Your Stats')
            .addFields(
              { name: 'Orders claimed', value: `${stats.orders_claimed}`, inline: true },
              { name: 'Total points', value: `${stats.total_weight}`, inline: true },
              { name: 'Rank', value: rank ? `#${rank}` : 'Unranked', inline: true },
            ),
        ],
        ephemeral: true,
      });
      return;
    }

    if (interaction.commandName === 'orders') {
      const open = getOpenOrderCount();
      await interaction.reply({
        content: open
          ? `📬 **${open}** order${open === 1 ? '' : 's'} waiting to be claimed in <#${ordersChannelId}>`
          : '✅ No open orders — all caught up!',
        ephemeral: true,
      });
    }
  } catch (err) {
    console.error('Interaction error:', err);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: 'Something went wrong.', ephemeral: true }).catch(() => {});
    } else {
      await interaction.reply({ content: 'Something went wrong.', ephemeral: true }).catch(() => {});
    }
  }
});

registerCommands()
  .then(() => client.login(token))
  .catch(console.error);
